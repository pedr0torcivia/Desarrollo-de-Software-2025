const arrayCategoria = [
    { IdCategoria: 1, Nombre: "Accesorios" },
    { IdCategoria: 2, Nombre: "Audio" },
    { IdCategoria: 3, Nombre: "Celulares" },
    { IdCategoria: 4, Nombre: "Cuidado Personal" },
    { IdCategoria: 5, Nombre: "Dvd" },
    { IdCategoria: 6, Nombre: "Fotografía" },
    { IdCategoria: 7, Nombre: "Frio-Calor" },
    { IdCategoria: 8, Nombre: "Gps" },
    { IdCategoria: 9, Nombre: "Informatica" },
]
export default arrayCategoria;
